"""Package for jax NN modules."""

__all__ = ["FNN"]

from .fnn import FNN

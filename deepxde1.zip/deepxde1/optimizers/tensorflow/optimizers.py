__all__ = ["get", "is_external_optimizer"]

from .tfp_optimizer import lbfgs_minimize
from ...backend import tf

import tensorflow.compat.v2 as tfc
#from keras.optimizer_v2 import optimizer_v2
from tensorflow.python.util.tf_export import keras_export
from tensorflow.python.framework import ops
from tensorflow.python.keras import backend_config
from tensorflow.python.keras.optimizer_v2 import optimizer_v2
from tensorflow.python.ops import array_ops
from tensorflow.python.ops import control_flow_ops
from tensorflow.python.ops import math_ops
from tensorflow.python.ops import state_ops
from tensorflow.python.util.tf_export import tf_export

from keras import backend as K  
from keras.optimizers import Optimizer

from scipy import special

def parameter(n):
    alpha = []
    for i in range(n):
        alpha.append(8.8 - 0.005**(i)) #0.8
    return alpha

def summation(n):
    summ = 0
    alpha = parameter(n)
    for i in range(n):
        summ += alpha[i]
    return summ

def Fisher(n):
    FIM = []
    alpha = parameter(n)
    for i in range(n):
        Row = []
        for j in range(n):
            if i == j: 
                Row.append(special.polygamma(1, alpha[i]) - special.polygamma(1, summation(n)))
            else:
            	#Row.append(0)
               Row.append(- special.polygamma(1, summation(n)))
        FIM.append(Row)
    FIM = numpy.array(FIM)
    FIM = numpy.linalg.inv(FIM)
    return FIM

class NGD_Dirichlet(optimizer_v2.OptimizerV2):
    _HAS_AGGREGATE_GRAD = True

    def __init__(self,
        learning_rate=0.001,
        momentum=0.99,
        nesterov=True,
        name="NGD_Dirichlet",
        **kwargs):
        super(NGD_Dirichlet, self).__init__(name, **kwargs)
        self._set_hyper("learning_rate", kwargs.get("lr", learning_rate))
        self._set_hyper("decay", self._initial_decay)
        self._momentum = False
        if isinstance(momentum, tf.Tensor) or callable(momentum) or momentum > 0:
            self._momentum = True
        if isinstance(momentum, (int, float)) and (momentum < 0 or momentum > 1):
            raise ValueError(f"`momentum` must be between [0, 1]. Received: "
                f"momentum={momentum} (of type {type(momentum)}).")
        self._set_hyper("momentum", momentum)
        self.nesterov = nesterov

    def _create_slots(self, var_list):
        if self._momentum:
            for var in var_list:
                self.add_slot(var, "momentum")

    def _prepare_local(self, var_device, var_dtype, apply_state):
        super(NGD_Dirichlet, self)._prepare_local(var_device, var_dtype, apply_state)
        apply_state[(var_device, var_dtype)]["momentum"] = tfc.identity(
            self._get_hyper("momentum", var_dtype))

    def _resource_apply_dense(self, grad, var, apply_state=None):
        var_device, var_dtype = var.device, var.dtype.base_dtype
        coefficients = ((apply_state or {}).get((var_device, var_dtype))
            or self._fallback_apply_state(var_device, var_dtype))

        if self._momentum:
          momentum_var = self.get_slot(var, "momentum")
          return tfc.raw_ops.ResourceApplyKerasMomentum(
              var=var.handle,
              accum=momentum_var.handle,
              lr=coefficients["lr_t"],
              grad=grad,
              momentum=coefficients["momentum"],
              use_locking=self._use_locking,
              use_nesterov=self.nesterov)
        else:
          return tfc.raw_ops.ResourceApplyGradientDescent(
              var=var.handle,
              alpha=coefficients["lr_t"],
              delta=grad,
              use_locking=self._use_locking)

    def _resource_apply_sparse_duplicate_indices(self, grad, var, indices, **kwargs):
        if self._momentum:
          return super(NGD_Dirichlet, self)._resource_apply_sparse_duplicate_indices(
              grad, var, indices, **kwargs)
        else:
          var_device, var_dtype = var.device, var.dtype.base_dtype
          coefficients = (kwargs.get("apply_state", {}).get((var_device, var_dtype))
            or self._fallback_apply_state(var_device, var_dtype))

        return tfc.raw_ops.ResourceScatterAdd(
            resource=var.handle,
            indices=indices,
            updates=np.dot(Fisher(len(grad)),grad.transpose()) * coefficients["lr_t"])

    def _resource_apply_sparse(self, grad, var, indices, apply_state=None):
        # This method is only needed for momentum optimization.
        var_device, var_dtype = var.device, var.dtype.base_dtype
        coefficients = ((apply_state or {}).get((var_device, var_dtype))
            or self._fallback_apply_state(var_device, var_dtype))

        momentum_var = self.get_slot(var, "momentum")
        return tfc.raw_ops.ResourceSparseApplyKerasMomentum(
            var=var.handle,
            accum=momentum_var.handle,
            lr=coefficients["lr_t"],
            grad=grad,
            indices=indices,
            momentum=coefficients["momentum"],
            use_locking=self._use_locking,
            use_nesterov=self.nesterov)

    def get_config(self):
        config = super(NGD_Dirichlet, self).get_config()
        config.update({
            "learning_rate": self._serialize_hyperparameter("learning_rate"),
            "decay": self._initial_decay,
            "momentum": self._serialize_hyperparameter("momentum"),
            "nesterov": self.nesterov,
        })
        return config

class DiffGrad(optimizer_v2.OptimizerV2):
    def __init__(self,
                 learning_rate=0.001,
                 beta_1=0.9,
                 beta_2=0.999,
                 epsilon=1e-7,
                 name='DiffGrad',
                 **kwargs):
        super(DiffGrad, self).__init__(name, **kwargs)
        #self.version = version
        self._set_hyper('learning_rate', kwargs.get('lr', learning_rate))
        self._set_hyper('decay', self._initial_decay)
        self._set_hyper('beta_1', beta_1)
        self._set_hyper('beta_2', beta_2)
        self.epsilon = epsilon or backend_config.epsilon()

    def _create_slots(self, var_list):
        # Create slots for the first and second moments.
        # Separate for-loops to respect the ordering of slot variables from v1.
        for var in var_list:
            self.add_slot(var, 'm')
        for var in var_list:
            self.add_slot(var, 'v')
        for var in var_list:
            self.add_slot(var, 'prev_g')

    def _prepare_local(self, var_device, var_dtype, apply_state):
        super(DiffGrad, self)._prepare_local(var_device, var_dtype, apply_state)

        local_step = math_ops.cast(self.iterations + 1, var_dtype)
        beta_1_t = array_ops.identity(self._get_hyper('beta_1', var_dtype))
        beta_2_t = array_ops.identity(self._get_hyper('beta_2', var_dtype))
        beta_1_power = math_ops.pow(beta_1_t, local_step)
        beta_2_power = math_ops.pow(beta_2_t, local_step)
        lr = (apply_state[(var_device, var_dtype)]['lr_t'] *
              (math_ops.sqrt(1 - beta_2_power) / (1 - beta_1_power)))
        apply_state[(var_device, var_dtype)].update(dict(
            lr=lr,
            epsilon=ops.convert_to_tensor(self.epsilon, var_dtype),
            beta_1_t=beta_1_t,
            beta_1_power=beta_1_power,
            one_minus_beta_1_t=1 - beta_1_t,
            beta_2_t=beta_2_t,
            beta_2_power=beta_2_power,
            one_minus_beta_2_t=1 - beta_2_t
        ))

    def set_weights(self, weights):
        params = self.weights
        num_vars = int((len(params) - 1) / 2)
        if len(weights) == 3 * num_vars + 1:
            weights = weights[:len(params)]
        super(DiffGrad, self).set_weights(weights)

    def _resource_apply_dense(self, grad, var, apply_state=None):
        var_device, var_dtype = var.device, var.dtype.base_dtype
        coefficients = ((apply_state or {}).get((var_device, var_dtype))
                        or self._fallback_apply_state(var_device, var_dtype))

        # m_t = beta1 * m + (1 - beta1) * g_t
        m = self.get_slot(var, 'm')
        m_scaled_g_values = grad * coefficients['one_minus_beta_1_t']
        m_t = state_ops.assign(m, m * coefficients['beta_1_t'] + m_scaled_g_values,
                               use_locking=self._use_locking)

        # v_t = beta2 * v + (1 - beta2) * (g_t * g_t)
        v = self.get_slot(var, 'v')
        v_scaled_g_values = (grad * grad) * coefficients['one_minus_beta_2_t']
        v_t = state_ops.assign(v, v * coefficients['beta_2_t'] + v_scaled_g_values,
                               use_locking=self._use_locking)

        # diffgrad
        prev_g = self.get_slot(var, 'prev_g')
        dfc = 1.0 / (1.0 + math_ops.exp(-math_ops.abs(prev_g - grad)))

        v_sqrt = math_ops.sqrt(v_t)
        var_update = state_ops.assign_sub(
            var, coefficients['lr'] * m_t * dfc / (v_sqrt + coefficients['epsilon']),
            use_locking=self._use_locking)

        new_prev_g = state_ops.assign(prev_g, grad, use_locking=self._use_locking)

        return control_flow_ops.group(*[var_update, m_t, v_t, new_prev_g])

    def _resource_apply_sparse(self, grad, var, indices, apply_state=None):
        raise RuntimeError('This optimizer does not support sparse gradients.')

    def get_config(self):
        config = super(DiffGrad, self).get_config()
        config.update({
            'learning_rate': self._serialize_hyperparameter('learning_rate'),
            'decay': self._serialize_hyperparameter('decay'),
            'beta_1': self._serialize_hyperparameter('beta_1'),
            'beta_2': self._serialize_hyperparameter('beta_2'),
            'epsilon': self.epsilon,
        })
        return config

class Apollo(optimizer_v2.OptimizerV2):
    """
    Implements Apollo algorithm.
        Arguments:
            learning_rate (float): learning rate (default: 0.01)
            beta (float, optional): coefficient used for computing running averages of gradient (default: 0.9)
            epsilon (float, optional): term added to the denominator to improve numerical stability (default: 1e-4)
            rebound (str, optional): rectified bound for diagonal hessian, 'belief' for scale-invariant:
                ``'constant'`` | ``'belief'`` (default: 'constant')
            weight_decay (float, optional): weight decay coefficient (default: 0.0)
    """

    _HAS_AGGREGATE_GRAD = True

    def __init__(
            self,
            learning_rate=0.01,
            beta=0.9,
            epsilon=1e-4,
            rebound='constant',
            weight_decay=0.0,
            name="ApolloOptimizer",
            **kwargs):
        super().__init__(name, **kwargs)
        assert rebound in ['constant', 'belief'], "rebound = 'constant' for normal or 'belief' for scale-invariant"
        self._set_hyper("learning_rate", kwargs.get("lr", learning_rate))
        self._set_hyper("beta", beta)
        self.epsilon = epsilon
        self.rebound_type = rebound
        self._set_hyper("weight_decay", weight_decay)
        self._has_weight_decay = weight_decay != 0.0

    def _create_slots(self, var_list):
        for var in var_list:
            self.add_slot(var, "exp_avg_grad")
        for var in var_list:
            self.add_slot(var, "approx_hessian")
        for var in var_list:
            self.add_slot(var, "update")

    def _decayed_wd(self, var_dtype):
        wd_t = self._get_hyper("weight_decay", var_dtype)
        if isinstance(wd_t, tf.keras.optimizers.schedules.LearningRateSchedule):
            wd_t = tf.cast(wd_t(self.iterations), var_dtype)
        return wd_t

    @tf.function
    def _resource_apply_dense(self, grad, var):
        var_dtype = var.dtype.base_dtype
        curr_lr = self._decayed_lr(var_dtype)
        weight_decay = self._decayed_wd(var_dtype)
        beta = self._get_hyper("beta", var_dtype)
        eps = tf.convert_to_tensor(self.epsilon, var_dtype)
        local_step = tf.cast(self.iterations + 1, var_dtype)

        exp_avg_grad = self.get_slot(var, "exp_avg_grad")
        B = self.get_slot(var, "approx_hessian")
        d_p = self.get_slot(var, "update")

        bias_correction = 1 - beta ** local_step
        alpha = (1 - beta) / bias_correction

        # calc the diff grad
        delta_grad = grad - exp_avg_grad
        if self.rebound_type == 'belief':
            rebound = tf.norm(delta_grad, ord=np.inf)
        else:
            rebound = 0.01
            eps = eps / rebound

        # Update the running average grad
        exp_avg_grad_t = exp_avg_grad.assign_add(delta_grad * alpha, use_locking=self._use_locking)

        denom = tf.math.pow(
            tf.math.reduce_sum(tf.math.pow(tf.math.abs(d_p), tf.constant(4.0))), tf.constant(1.0/4.0)) + eps
        d_p_t = d_p / denom
        v_sq = d_p_t ** 2
        delta = tf.math.reduce_sum((delta_grad / denom) * d_p_t) * -alpha - tf.math.reduce_sum(B * v_sq)

        # Update B
        B_t = B.assign_add(v_sq * delta, use_locking=self._use_locking)

        # calc direction of parameter updates
        if self.rebound_type == 'belief':
            denom = tf.math.maximum(tf.math.abs(B_t), rebound) + eps / alpha
        else:
            denom = tf.math.maximum(tf.math.abs(B_t), rebound)

        d_p_t = exp_avg_grad_t / denom

        # Perform step weight decay (decoupled)
        if self._has_weight_decay:
            d_p_t = d_p.assign(d_p_t + var * weight_decay)
        else:
            d_p_t = d_p.assign(d_p_t)

        var.assign_add(d_p_t * -curr_lr, use_locking=self._use_locking)

    def _resource_apply_sparse(self, grad, var, indices):
        raise "This implementation of Apollo does not support sparse gradients"

    def get_config(self):
        config = super().get_config()
        config.update(
            {
                "learning_rate": self._serialize_hyperparameter("learning_rate"),
                "beta": self._serialize_hyperparameter("beta"),
                "epsilon": self.epsilon,
                "rebound": self.rebound_type,
                "weight_decay": self._serialize_hyperparameter("weight_decay"),
            }
        )
        return config

class Yogi(optimizer_v2.OptimizerV2):
    def __init__(self,
                 learning_rate=0.001,
                 beta_1=0.9,
                 beta_2=0.999,
                 epsilon=1e-7,
                 name='Yogi',
                 **kwargs):
        super(Yogi, self).__init__(name, **kwargs)
        self._set_hyper('learning_rate', kwargs.get('lr', learning_rate))
        self._set_hyper('decay', self._initial_decay)
        self._set_hyper('beta_1', beta_1)
        self._set_hyper('beta_2', beta_2)
        self.epsilon = epsilon or backend_config.epsilon()

    def _create_slots(self, var_list):
        # Create slots for the first and second moments.
        # Separate for-loops to respect the ordering of slot variables from v1.
        for var in var_list:
            self.add_slot(var, 'm')
        for var in var_list:
            self.add_slot(var, 'v')
        for var in var_list:
            self.add_slot(var, 'prev_g')

    def _prepare_local(self, var_device, var_dtype, apply_state):
        super(Yogi, self)._prepare_local(var_device, var_dtype, apply_state)

        local_step = math_ops.cast(self.iterations + 1, var_dtype)
        beta_1_t = array_ops.identity(self._get_hyper('beta_1', var_dtype))
        beta_2_t = array_ops.identity(self._get_hyper('beta_2', var_dtype))
        beta_1_power = math_ops.pow(beta_1_t, local_step)
        beta_2_power = math_ops.pow(beta_2_t, local_step)
        lr = (apply_state[(var_device, var_dtype)]['lr_t'] *
              (math_ops.sqrt(1 - beta_2_power) / (1 - beta_1_power)))
        apply_state[(var_device, var_dtype)].update(dict(
            lr=lr,
            epsilon=ops.convert_to_tensor(self.epsilon, var_dtype),
            beta_1_t=beta_1_t,
            beta_1_power=beta_1_power,
            one_minus_beta_1_t=1 - beta_1_t,
            beta_2_t=beta_2_t,
            beta_2_power=beta_2_power,
            one_minus_beta_2_t=1 - beta_2_t
        ))

    def set_weights(self, weights):
        params = self.weights
        num_vars = int((len(params) - 1) / 2)
        if len(weights) == 3 * num_vars + 1:
            weights = weights[:len(params)]
        super(Yogi, self).set_weights(weights)

    def _resource_apply_dense(self, grad, var, apply_state=None):
        var_device, var_dtype = var.device, var.dtype.base_dtype
        coefficients = ((apply_state or {}).get((var_device, var_dtype))
                        or self._fallback_apply_state(var_device, var_dtype))

        # m_t = beta1 * m + (1 - beta1) * g_t
        m = self.get_slot(var, 'm')
        m_scaled_g_values = grad * coefficients['one_minus_beta_1_t']
        m_t = state_ops.assign(m, m * coefficients['beta_1_t'] + m_scaled_g_values,
                               use_locking=self._use_locking)

        # v_t = beta2 * v + (1 - beta2) * (g_t * g_t)
        v = self.get_slot(var, 'v')
        v_scaled_g_values = abs(v - grad*grad)*(grad * grad) * coefficients['one_minus_beta_2_t']
        v_t = state_ops.assign(v, v * coefficients['beta_2_t'] + v_scaled_g_values,
                               use_locking=self._use_locking)

        # diffgrad
        prev_g = self.get_slot(var, 'prev_g')
        dfc = 1.0 / (1.0 + math_ops.exp(-math_ops.abs(prev_g - grad)))

        v_sqrt = math_ops.sqrt(v_t)
        var_update = state_ops.assign_sub(
            var, coefficients['lr'] * m_t * dfc / (v_sqrt + coefficients['epsilon']),
            use_locking=self._use_locking)

        new_prev_g = state_ops.assign(prev_g, grad, use_locking=self._use_locking)

        return control_flow_ops.group(*[var_update, m_t, v_t, new_prev_g])

    def _resource_apply_sparse(self, grad, var, indices, apply_state=None):
        raise RuntimeError('This optimizer does not support sparse gradients.')

    def get_config(self):
        config = super(Yogi, self).get_config()
        config.update({
            'learning_rate': self._serialize_hyperparameter('learning_rate'),
            'decay': self._serialize_hyperparameter('decay'),
            'beta_1': self._serialize_hyperparameter('beta_1'),
            'beta_2': self._serialize_hyperparameter('beta_2'),
            'epsilon': self.epsilon,
        })
        return config


def is_external_optimizer(optimizer):
    return optimizer in ["L-BFGS", "L-BFGS-B"]


def get(optimizer, learning_rate=None, decay=None):
    """Retrieves a Keras Optimizer instance."""
    if isinstance(optimizer, tf.keras.optimizers.Optimizer):
        return optimizer
    if is_external_optimizer(optimizer):
        if learning_rate is not None or decay is not None:
            print("Warning: learning rate is ignored for {}".format(optimizer))
        return lbfgs_minimize

    if learning_rate is None:
        raise ValueError("No learning rate for {}.".format(optimizer))

    lr_schedule = _get_learningrate(learning_rate, decay)
    if optimizer == "adam":
        return tf.keras.optimizers.Adam(learning_rate=lr_schedule)
    if optimizer == "adagrad":
        return tf.keras.optimizers.Adagrad(learning_rate=lr_schedule)
    if optimizer == "rmsprop":
        return tf.keras.optimizers.RMSprop(learning_rate=lr_schedule)
    if optimizer == "adadelta":
        return tf.keras.optimizers.Adadelta(learning_rate=lr_schedule)
    if optimizer == "sgdm nesterov":
        return tf.keras.optimizers.SGD(learning_rate=lr_schedule, momentum = 0.99, nesterov = True)
    if optimizer == "ngd":
        return NGD_Dirichlet(learning_rate=lr_schedule, momentum = 0.99, nesterov = True)
    if optimizer == "diffgrad":
    	return DiffGrad(learning_rate=lr_schedule)
    if optimizer == "apollo":
        return Apollo(learning_rate=lr_schedule)
    if optimizer == "yogi":
        return Yogi(learning_rate=lr_schedule)

    raise NotImplementedError(f"{optimizer} to be implemented for backend tensorflow.")


def _get_learningrate(lr, decay):
    if decay is None:
        return lr

    if decay[0] == "inverse time":
        return tf.keras.optimizers.schedules.InverseTimeDecay(lr, decay[1], decay[2])
    if decay[0] == "cosine":
        return tf.keras.optimizers.schedules.CosineDecay(lr, decay[1], alpha=decay[2])

    raise NotImplementedError(
        f"{decay[0]} learning rate decay to be implemented for backend tensorflow."
    )
